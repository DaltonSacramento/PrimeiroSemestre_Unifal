/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Pichau
 *
 * Created on 22 de março de 2024, 09:52
 */

#include <cstdlib>
#include <stdio.h>
#include <iostream>
#define SB AD*VA
#define SL SB*DINSS

using namespace std;

/*
 * Construir um algoritmo que efetue o cálculo do salário líquido
de um professor. Para fazer os cálculos são necessários alguns
dados como: o valor da hora/aula, número de aulas dadas no
mês e percentual de desconto do INSS.
 */


int main(int argc, char** argv) {
    
    float AD, VA, DINSS;
    
    int values;
    DINSS=0;
    
    cout<<"\nInforme a quantidade de aulas dadas por mês: ";
    cin>>AD;
    cout<<"\nDigite o valor cobrado por aula: ";
    cin>>VA;
    
    cout<<"\nO salário bruto do professor é: "<<SB;
    
    
    if(SB>0 && SB<=1412.00){
        DINSS=0.925;
    }
    else{
        if(SB>1412.00 && SB<=2666.68){
            DINSS=0.91;
        }
        else{
            if(SB>2666.68 && SB<=4000.03){
                DINSS=0.88;
            }
            else{
                if(SB>4000.03 && SB<=7786.02){
                    DINSS=0.86;
                }
            }
        }
    }
    
    cout<<"\nO salário líquido do professor após os descontos é: "<<SL;

    return 0;
}

