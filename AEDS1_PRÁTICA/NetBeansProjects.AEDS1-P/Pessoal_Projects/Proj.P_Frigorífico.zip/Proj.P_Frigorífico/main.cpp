/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Pichau
 *
 * Created on 22 de março de 2024, 10:48
 */

#include <cstdlib>
#include <stdio.h>
#include <limits>
#include <string>
#include <cctype>
#include <iostream>

using namespace std;

/*
 * Num frigorífico existem 90 bois. Cada boi traz no seu pescoço
um cartão contendo seu número de identificação e seu peso.
Fazer um algoritmo que escreva o número e o peso do boi
mais gordo e do boi mais magro.
 */

int main(int argc, char** argv) {
    
    float n, PESO;
    
    int values;
    n=0;
    PESO=1;
    
    string R;
    
    int menorPeso=numeric_limits<int>::max();
    
    cout<<"Digite iniciar para começar a cadastrar os animais: ";
    cin>>R;
    if(R=="iniciar"){
        cout<<"Digite o peso do boi: ";
        cin>>PESO;
        while(PESO>0){
        cout<<"Digite o peso do boi: ";
        n=n+1;
        if (PESO<menorPeso){
            menorPeso=PESO;
        }
        cin>>PESO;
    }
    cout<<"\nO animal com menor peso é o boi número: "<<n;
    cout<<"\nO seu peso é de: "<<menorPeso<<"kg";
    }
    
    return 0;
}

