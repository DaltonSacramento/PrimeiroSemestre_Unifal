/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   Projeto_Pessoal_Temperaturas
 * Author: DDS28
 * Created on 18 de março de 2024, 10:43
 */

#include <cstdlib>
#include <stdio.h>
#include <iostream>
#define TTCF TC*1.8+32
#define TTCK TC+273
#define TTFC (TF-32)*5/9
#define TTFK (TF+459.67)*5/9
#define TTKC TK-273
#define TTKF (TK-273)*9/5+32

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    float C1, TC;
    float C2, TF;
    float C3, TK;
    
    cout<<"\nSe você quer tranformar uma temperatura que está em °C, digite 1, "
            "se não digite 0: ";
    cin>>C1;
    while(C1!=1 && C1!=0){
        cout<<"\nValor incorreto. Digite novamente: ";
        cin>>C1;
    }
    
    if(C1==1){
        cout<<"\nDigite a temperatura em °C: ";
        cin>>TC;
        cout<<"\nA temperatura especificada em °F é: "<<TTCF;
        cout<<"\nA temperatura especificada em °K é: "<<TTCK;
    }
    else{
        if(C1==0){
            cout<<"\nSe você quer tranformar uma temperatura que está em °F, "
                    "digite 1, se não digite 0: ";
            cin>>C2;
            while(C2!=0 && C2!=1){
                 cout<<"\nValor incorreto. Digite novamente: ";
                 cin>>C2;
            }
        }
            if(C2==1){
                cout<<"\nDigite a temperatura em °F: ";
                cin>>TF;
        
                cout<<"\nA temperatura especificada em °C é: "<<TTFC;
                cout<<"\nA temperatura especificada em °K é: "<<TTFK;
            }
            else{
                if(C2==0){
                 cout<<"\nSe você quer tranformar uma temperatura que está em "
                         "°K, digite 1, se não digite 0: ";
                 cin>>C3;
                 while(C3!=0 && C3!=1){
                 cout<<"\nValor incorreto. Digite novamente: ";
                 cin>>C3;    
                 }
                }
                if(C3==1){
                    cout<<"Digite a temperatura em °K: ";
                    cin>>TK;
                    
                     cout<<"\nA temperatura especificada em °C é: "<<TTKC;
                     cout<<"\nA temperatura especificada em °F é: "<<TTKF;
                }
            }
    }
    
    
    
    

return 0;
}

