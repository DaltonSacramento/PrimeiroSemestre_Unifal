/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: DDS28
 * Created on 21 de março de 2024, 14:57
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <cctype>
#include <string>

using namespace std;

/*
 * A empresa XYZ fez uma pesquisa de mercado para saber se seus clientes 
 * gostaram ou não de um novo produto que foi lançado pela empresa recentemente. 
 * Para isto, perguntou a idade e se o cliente gostou ou não do produto. 
 * Sabendo-se que foram feitas 200 entrevistas,fazer um algoritmo que calcule 
 * e escreva:
 A quantidade de pessoas entrevistadas.
 O número de pessoas que responderam sim.
 O número de pessoas que responderam não.
 a média de idade das pessoas que responderam sim.
 */


int main(int argc, char** argv) {
    
    float x, y, z, a, ID;
    
    int values;
    x=0;
    z=0;
    y=0;
    a=0;
    
    string R;
    
    cout<<"\nDigite desejo se você deseja participar da entrevista: ";
    cin>>R;
    if(R=="sim"){
        while(R=="sim" or R=="nao"){
        cout<<"\nDigite sim se gostou e nao se não gostou do novo produto: ";
        x=x+1;
        cin>>R;
        
         if(R=="sim"){
         cout<<"\nDigite a sua idade: ";
         cin>>ID;
         a=a+ID;
         }
        
          if(R=="nao"){
          cout<<"\nDigite a sua idade: ";
          cin>>ID;
          }
        
           if(R=="sim"){
           y=y+1;
           }
        
            if(R=="nao"){
            z=z+1;
            }
        
        }
    }
    else
        if(R=="nao"){
            cout<<"Ok, obrigado pela atenção!";
        }
    
    if(R=="parar"){
        cout<<"\nA quantidade de pessoas entrevistadas foi:"<<x-1;
        cout<<"\nA quantidade que gostou do produto:"<<y;
        cout<<"\nA quantidade que não gostou do produto é:"<<z;
        cout<<"\nA média das idades de quem gostou do produto é:"<<a/y;
    }
        
   

    return 0;
}

