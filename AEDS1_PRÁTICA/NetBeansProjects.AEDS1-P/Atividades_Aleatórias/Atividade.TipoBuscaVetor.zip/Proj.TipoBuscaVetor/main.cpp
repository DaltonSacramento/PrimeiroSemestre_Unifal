/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Pichau
 *
 * Created on 10 de abril de 2024, 20:28
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <stdio.h>
#include <math.h>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    int x, y, z;
    float valor, InicioIntervalo, FimIntervalo;
    float altura[1000];
    int opção;
    
    
    
    cout<<"\nTipos de busca num vetor\n"<<endl;
    srand(time(NULL));
    
    
    
    cout<<"\nDigite 1 se deseja descobrir se um certo valor existe no vetor, e "
            "qual sua posição.";
    cout<<"\nDigite 2 se deseja descobrir quantas vezes um valor apareceu no vetor"
            "e quais as suas posições.";
    cout<<"\nDigite 3 se deseja descobrir quantas vezes os valores de um intervalo"
            "aparecem no vetor.";
    
    
    
    do{
        for(x=0; x<1000; x++){
        altura[x]= 101+rand()%100;
        }
        
        cout<<"\n\nDigite aqui qual opção deseja(1,2 ou 3): ";
        cin>>opção;
        switch(opção){
            
            
            case 1:
                cout<<"\nDigite um valor de 100 a 200 que deseje saber se "
                        "existe e qual sua posição: ";
                cin>>valor;
                
                y=0;
                z=0;
                for(x=0; x<1000; x++){ 
                    if(altura[x]==valor){
                        y++;
                        if(y==1){
                        cout<<"\nO valor digitado EXISTE no vetor.";
                        }
                        cout<<"\nSua "<<y<<"º posição entre os mil numeros é: "
                                ""<<x<<"º";
                    }
                    else{
                        z++;
                        if(z==1000){
                        cout<<"\nO valor digitado NAO EXISTE no vetor.";
                        }
                    }
                }
                break;
                
                
                
                
            case 2:
                cout<<"\nDigite um valor de 100 a 200 que voce deseje saber "
                        "quantas vezes aparece no vetor e quais suas posições: ";
                cin>>valor;
                
                y=0;
                for(x=0; x<1000; x++){ 
                    if(altura[x]==valor){
                        y++;
                        cout<<"\nSua "<<y<<"º posição entre os mil numeros é: "
                                ""<<x<<"º";
                    }
                }
                cout<<"\nO valor digitado aparece "<<y<<" vezes no vetor.";
                break;
                
                
                
                
            case 3:
                cout<<"\nDigite um intervalo de 100 a 200 que deseje descobrir "
                        "quantas vezes aparece no vetor.";
                cout<<"\nO intervalo irá do numero: ";
                cin>>InicioIntervalo;
                cout<<"Até o numero: ";
                cin>>FimIntervalo;
                
                y=0;
                for(x=0; x<1000; x++){ 
                    if(altura[x]>=InicioIntervalo && altura[x]<=FimIntervalo){
                        y++;
                    }
                }
                cout<<"\nOs valores do intervalo aparecem no vetor "<<y<<""
                            " vezes.";
                break;
                
                
        }
    } while(opção!=0);
            
    
    

    return 0;
}

