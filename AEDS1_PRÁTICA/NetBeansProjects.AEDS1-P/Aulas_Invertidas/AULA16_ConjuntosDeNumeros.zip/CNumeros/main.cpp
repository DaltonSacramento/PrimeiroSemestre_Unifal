/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File: Atividade_ConjuntosDeNumeros
 * Author: Dalton D'Angelis Sacramento
 * Created on 24 de abril de 2024, 18:39
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <stdio.h>
#include <math.h>

using namespace std;

/*
 * O codigo a seguir foi criado em c++ e tem o objeto de ajudar o programador a
 * conhecer e implementar as operações basicas sobre conjunto de valores. Além
 * disso, o codigo também mostra ao usuário o resultado de algumas operações
 * em vetores, como a retirada de numero repetidos e a uniao entre os vetores.
 */

int main(int argc, char** argv) {

    int conjunto1[10] = {5, 4, 2, 5, 3, 2, 4, 8, 2, 9};
    int conjunto2[10] = {7, 1, 12, 10, 9, 2, 8, 1, 2, 7};
    int Uniao[20];
    int Intersecçao[20];
    int x, y, z;
    
    int tam1 = 10, tam2 = 10, tamUniao = 0, tamInter=0;
    
    cout << "\nOperações em conjuntos de valores.\n" << endl;
    
    cout<<"\n-----------------------------------------------------------------";
    
    y=0;
    z=0;
    for(x=0; x<tam1; x++){
        for (y=x+1; y<tam1; y++){
            if(conjunto1[x]==conjunto1[y]){ 
                tam1=tam1-1;
                for (z=y; z<tam1; z++){
                conjunto1[z]=conjunto1[z+1];
                }
                y==x;
            }
        }
    }
    cout<<"\n\nO tamanho do vetor(conjunto1) após a retirada das "
            "repetições é: "<<tam1;
    cout<<"\nO vetor após a operação ficará: ";
    for(x=0; x<tam1; x++){
        cout<<"<>"<<conjunto1[x];

    }
    y=0;
    z=0;
    for(x=0; x<tam2; x++){
        for (y=x+1; y<tam2; y++){
            if(conjunto2[x]==conjunto2[y]){ 
                tam2=tam2-1;
                for(z=y; z<tam2; z++){
                    conjunto2[z]=conjunto2[z+1];
                }
                y==x;
            }
        }
    }
    cout<<"\n\nO tamanho do vetor(conjunto2) após a retirada das "
            "repetições é: "<<tam2;
    cout<<"\nO vetor após a operação ficará: ";
    for(x=0; x<tam2; x++){
        cout<<"<>"<<conjunto2[x];
    }
    
    
    cout<<"\n-----------------------------------------------------------------";
    
    
    y=0;
    for(x=0; x<tam1; x++){
        Uniao[x]=conjunto1[y];
        tamUniao++;
        y++;
    }
    z=0;
    for(x=0; x<tam2; x++){
        Uniao[x+y]=conjunto2[z];
        tamUniao++;
        z++;
    }
    y=0;
    z=0;
    for(x=0; x<tamUniao; x++){
        for (y=x+1; y<tamUniao; y++){
            if(Uniao[x]==Uniao[y]){ 
                tamUniao=tamUniao-1;
                for (z=y; z<tamUniao; z++){
                    Uniao[z]=Uniao[z+1];
                }
                y==x;
            }
        }
    }
    cout<<"\n\nO tamanho do vetor de uniao é: "<<tamUniao;
    cout<<"\nO vetor é: ";
    for(x=0; x<tamUniao; x++){
        cout<<"<>"<<Uniao[x];
    }
    
    
    cout<<"\n-----------------------------------------------------------------";
    
    
    y=0;
    z=0;
    for(x=0; x<tam1; x++){
        for(y=0; y<tam2; y++){
            if(conjunto1[x]==conjunto2[y]){
                Intersecçao[z]=conjunto1[x];
                tamInter++;
                z++;
            }
        }
        y++;
    }
    cout<<"\n\nO tamanho do vetor de intersecção é: "<<tamInter;
    cout<<"\nO vetor é: ";
    for(x=0; x<tamInter; x++){
        cout<<"<>"<<Intersecçao[x];
    }
    
    cout<<"\n-----------------------------------------------------------------";
    
    
    //@@@@@@@@@@@@@@@@@@@@@@@@//CODIGO MELHORADO//@@@@@@@@@@@@@@@@@@@@@@@@@@@//
    
    
    int conjunto1M[10] = {5, 4, 2, 5, 3, 2, 4, 8, 2, 9};
    int conjunto2M[10] = {7, 1, 12, 10, 9, 2, 8, 1, 2, 7};
    int UniaoM[20];
    int IntersecçaoM[20];
    
    int tam1M = 10, tam2M = 10, tamUniaoM = 0, tamInterM = 0;
    
    cout << "\n\nOperações em conjuntos de valores MELHORADO." << endl;
    
    cout<<"\n\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@";
    

    for(x=0, y=0, z=0; x<tam1M; x++){
        for (y=x+1; y<tam1M; y++){
            if(conjunto1M[x]==conjunto1M[y]){ 
                tam1M--;
                for (z=y; z<tam1M; z++){
                conjunto1M[z]=conjunto1M[z+1];
                }
                y==x;
            }
        }
    }
    cout<<"\n\nO tamanho do vetor(conjunto1) após a retirada das "
            "repetições é: "<<tam1M;
    cout<<"\nO vetor após a operação ficará: ";
    for(x=0; x<tam1M; x++){
        cout<<"<>"<<conjunto1M[x];

    }
    
    for(x=0, y=0, z=0; x<tam2M; x++){
        for (y=x+1; y<tam2M; y++){
            if(conjunto2M[x]==conjunto2M[y]){ 
                tam2M--;
                for(z=y; z<tam2M; z++){
                    conjunto2M[z]=conjunto2M[z+1];
                }
                y==x;
            }
        }
    }
    cout<<"\n\nO tamanho do vetor(conjunto2) após a retirada das "
            "repetições é: "<<tam2M;
    cout<<"\nO vetor após a operação ficará: ";
    for(x=0; x<tam2M; x++){
        cout<<"<>"<<conjunto2M[x];
    }
    
    
    cout<<"\n\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@";
    
    
    for(x=0, y=0; x<tam1M; x++, y++, tamUniaoM++){
        UniaoM[x]=conjunto1M[y];
    }
    for(x=0, z=0; x<tam2M; x++, z++, tamUniaoM++){
        UniaoM[x+y]=conjunto2M[z];
    }
    for(x=0, y=0, z=0; x<tamUniaoM; x++){
        for (y=x+1; y<tamUniaoM; y++){
            if(UniaoM[x]==UniaoM[y]){ 
                tamUniaoM--;
                for (z=y; z<tamUniaoM; z++){
                    UniaoM[z]=UniaoM[z+1];
                }
                y==x;
            }
        }
    }
    cout<<"\n\nO tamanho do vetor de uniao é: "<<tamUniao;
    cout<<"\nO vetor é: ";
    for(x=0; x<tamUniaoM; x++){
        cout<<"<>"<<UniaoM[x];
    }
    
    
    cout<<"\n\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@";
    
    
    for(x=0, y=0, z=0; x<tam1M; x++, y++){
        for(y=0; y<tam2M; y++){
            if(conjunto1M[x]==conjunto2M[y]){
                IntersecçaoM[z]=conjunto1M[x];
                tamInterM++;
                z++;
            }
        }
    }
    cout<<"\n\nO tamanho do vetor de intersecção é: "<<tamInter;
    cout<<"\nO vetor é: ";
    for(x=0; x<tamInterM; x++){
        cout<<"<>"<<IntersecçaoM[x];
    }
    
    
    
    return 0;
}

