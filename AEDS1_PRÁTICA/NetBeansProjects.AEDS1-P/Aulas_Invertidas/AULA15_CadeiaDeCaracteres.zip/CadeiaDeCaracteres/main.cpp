/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File: Cadeia de Caracteres
 * Author: Dalton D'Angelis Sacramento
 * Created on 22 de abril de 2024, 17:22
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <stdio.h>
#include <math.h>

using namespace std;

/*
 * Este é um projeto criado na linguagem c++ que busca esninar ao programador
 * a compreender e manipular caracteres num vetor de caracteres, além de
 * mostrar ao usuário algumas variações do seu nome completo e possibilita-lo
 * de fazer buscas de nome no vetor.
 */
int main(int argc, char** argv) {
    
    char nome[31], sobrenome[31], nomecompleto[62], NomeP[30];
    int x, y, z, b;
    
    nome[0] = 68;
    nome[1] = 97;
    nome[2] = 108;
    nome[3] = 116;
    nome[4] = 111;
    nome[5] = 110;
    nome[6] = 0;
    printf("\n Nome: %s.\n", nome);

    sobrenome[0] = 68;
    sobrenome[1] = 97;
    sobrenome[2] = 110;
    sobrenome[3] = 103;
    sobrenome[4] = 101;
    sobrenome[5] = 108;
    sobrenome[6] = 105;
    sobrenome[7] = 115;
    sobrenome[8] = 0;
    printf("\n Sobrenome: %s.\n", sobrenome);
    

    x=0;
    z=0;
    y=0;
    while(nome[y]!=0){
        nomecompleto[x]=nome[y];
        x++;
        y++;
    }
    nomecompleto[x]=32;
    
    
    
    z=0;
    while(sobrenome[z]!=0){
        nomecompleto[x+1]=sobrenome[z];
        x++;
        z++;
    }
    printf("\n Nome completo: %s.\n", nomecompleto);
    
    
    
    x=0;
    while(nomecompleto[x]!=0){
        if(nomecompleto[x]>=97 && nomecompleto[x]<=122){
            nomecompleto[x]=nomecompleto[x]-32;
        }
        x++;
    }
    printf("\n Nome completo 2: %s.\n", nomecompleto);
    
    
    
    x=0;
    y=0;
    x=x+1;
    while(nomecompleto[x]!=0){
        y=x-1;
        if(nomecompleto[y]!=32 && nomecompleto[x]!=32){
            nomecompleto[x]=nomecompleto[x]+32;  
        }
        x++;
    }
    printf("\n Nome completo 3: %s.\n", nomecompleto);
    
    
    
    
    x=0;
    y=0;
    while(nomecompleto[x]!=0){
        if(nomecompleto[x]==32){
            y=x;
            while(nomecompleto[y]!=0){
            nomecompleto[y]=nomecompleto[y+1];
            y++;
            }
        }
        x++;
    } 
    printf("\n Nome completo 4: %s.\n", nomecompleto);
    
    
    
    
    cout<<"\nDigite um nome ou sobrenome que deseje procurar no vetor: ";
    cin>>NomeP;
    z=0;
    x=0;
    y=0;
    while(nomecompleto[x]!=0){
        if(nomecompleto[x]==NomeP[0]){
            b=x;
            z=1;
            while(NomeP[y]!=0){
                if(nomecompleto[b]==NomeP[y]){
                    z=1;
                }
                else{
                    z=0;
                }
                y++;
                b++;
            }
        }
        x++;
    }
    if(z==1){
        printf("\n O nome digitado existe no vetor");
    }
    else {
        printf("\n O nome digitado não existe no vetor");
    }
    
    

    
    return 0;
}

