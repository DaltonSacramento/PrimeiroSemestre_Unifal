/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   Trabalho_NúmerosAleatórios
 * Author: Dalton D'Angelis Sacramento
 * Created on 27 de março de 2024, 18:48
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <stdio.h>
#define CP (z*100)/1000  /*A sigla CP equivale a "cálculo da porcentagem*/

using namespace std;


/*
 * Este código foi feito na linguagem C++ com o intuito de criar um programa
 * onde sejam gerados 1000 números aleatórios entre 1.5 e 2.3, conseguintemente,
 * com os valores criados, seriam calculadas a maior altura, a menor altura e a
 * porcentagem de pessoas maiores que 2,0 metros.
 */


int main(int argc, char** argv) {
    
    float x, y, z, Alturas, MaiorAltura, MenorAltura;
    
    x=0; /*Para contagem da quantidade de repetições*/
    z=0; /*Para contagem da quantidade de pessoas maiores que 2 metros*/
    y=0; /*Para atribuição dos valores das alturas e o posterior
          * cálculo da média*/
    
    cout<<"\nPROJETO - Criação de alturas aleatórias\n"<<endl;
    srandom(time(NULL));  
    
    MenorAltura=10000; /*O valor "10000" foi atribuído à variável MenorAltura
                       * para iniciar a condição do segundo "if" da estrutura
                       * de repetição.*/
    MaiorAltura=0; /* Da mesma forma que ocorreu a atribuição à variável
                    * MenorAltura, a variável MaiorAltura teve o valor "0"
                    * atribuído à mesma de acordo com a mesma lógica da
                    * anterior*/
    
    while(x<1000){
        x=x+1;
        Alturas = rand()%(2300+1-1500)+1500;
        y=y+Alturas;
        if(Alturas>MaiorAltura){
            MaiorAltura=Alturas;
        }
        if(Alturas<MenorAltura){
            MenorAltura=Alturas;
        }
        if(Alturas>2000){
            z=z+1;
        }
    }
    cout<<"A média das alturas geradas entre 1.5 e 2.3 é: "<<(y/1000)/1000
            <<" metros"<<endl;
    cout<<"A maior altura gerada é: "<<MaiorAltura/1000<<" metros"<<endl;
    cout<<"A menor altura gerada é: "<<MenorAltura/1000<<" metros"<<endl;
    cout<<"A porcentagem de pessoas maiores que 2 metros é: "<<CP<<"%"<<endl;

    return 0;
}

