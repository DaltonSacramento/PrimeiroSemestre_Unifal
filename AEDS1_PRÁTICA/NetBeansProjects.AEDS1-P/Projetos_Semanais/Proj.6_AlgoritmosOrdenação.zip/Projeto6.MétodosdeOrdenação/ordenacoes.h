/* 
 * File:   ordenacoes.h
 * Author: Dalton D'Angelis Sacramento
 * Created on 14 de junho de 2024, 09:48
 */

#ifndef ORDENACOES_H
#define ORDENACOES_H

typedef int Tvetor[100000];
int opçao();
void crescente(int vCresc[], int TAM);
void decrescente(int vDecresc[], int TAM);
void aleatório(int vAl[], int TAM); 
unsigned long long int bubblesort(int vB[], int tam);
unsigned long long int insertionsort(int vI[], int tam);
unsigned long long int selectionsort(int vS[], int tam);

#endif /* ORDENACOES_H */

