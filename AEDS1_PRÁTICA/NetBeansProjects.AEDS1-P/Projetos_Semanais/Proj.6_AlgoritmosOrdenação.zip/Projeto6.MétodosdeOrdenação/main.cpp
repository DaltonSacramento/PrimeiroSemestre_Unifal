/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Dalton D'Angelis Sacramento
 * Created on 14 de junho de 2024, 09:45
 */

#include <cstdlib>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <string>
#include <time.h>
#include <fstream>
#include "ordenacoes.h"


using namespace std;
ofstream arquivoS("arquivo.txt");

//Geração do vetor crescente
void crescente(int vCresc[], int TAM){
    int x;
    
    for(x=0; x<TAM ; x++){
        vCresc[x]=x;
        arquivoS<<" "<<vCresc[x];
    }
    arquivoS<<endl;
}

//Geração do vetor decrescente
void decrescente(int vDecresc[], int TAM){
    int x, Dec;
    
    Dec=TAM;
    for(x=0; x<TAM ; x++){
        vDecresc[x]=Dec;
        arquivoS<<" "<<vDecresc[x];
        Dec--;
    }
    arquivoS<<endl;
}

//Geração do vetor aleatório
void aleatório(int vAl[], int TAM){
    int x;
    int y = 0;
    //Atribuição de um valor "inválido" ao vetor
    for(x=0; x<TAM ; x++){
        vAl[x]=-1;
    }
    //Troca das posições do vetor que contém o valor "inválido" por valores 
    //"válidos" que não se repetem
    for(x=0; x<TAM ; x++){
        y = rand()%TAM;
        while(vAl[y%TAM]!=-1){
            y++;
        }
        vAl[y%TAM]=x;
        arquivoS<<" "<<vAl[y%TAM];
    }
    arquivoS<<endl;
}

/*
 *
 */
int main(int argc, char** argv) {
    
    //Semente para geração de valores
    srand(time(NULL));
    //Vetores utilizados para as análises
    Tvetor vCresc;
    Tvetor vDecresc;
    Tvetor vAl;
    //Tamanho dos vetores
    int TAM;
    //Variável contadora geral
    int x;
    
    cout<<"\nDigite o tamanho desejado para os vetores: ";
    cin>>TAM;
    
    
    //Switch do Menu
    //Variável para receber escolha do usuário
    x=0;
    do{
        switch (x=opçao()){
            //Bubble
            case 1:
                //Geração dos vetores crescente, decrescente e aleatório
                crescente(vCresc, TAM);
                decrescente(vDecresc, TAM);
                aleatório(vAl, TAM);
                
                cout<<"\nNúmero de oprações realizadas Algoritmo BubbleSort:";
                cout<<"\nVetor Crescente: "<<bubblesort(vCresc, TAM);
                cout<<"\nVetor Decrescente: "<<bubblesort(vDecresc, TAM);
                cout<<"\nVetor Aleatório: "<<bubblesort(vAl, TAM);                
                break;
            
            //Insertion    
            case 2:
                //Geração dos vetores crescente, decrescente e aleatório
                crescente(vCresc, TAM);
                decrescente(vDecresc, TAM);
                aleatório(vAl, TAM);
                
                cout<<"\nNúmero de oprações realizadas Algoritmo InsertionSort:";
                cout<<"\nVetor Crescente: "<<insertionsort(vCresc, TAM);
                cout<<"\nVetor Decrescente: "<<insertionsort(vDecresc, TAM);
                cout<<"\nVetor Aleatório: "<<insertionsort(vAl, TAM);        
                break;
            
            //Selection
            case 3:
                //Geração dos vetores crescente, decrescente e aleatório
                crescente(vCresc, TAM);
                decrescente(vDecresc, TAM);
                aleatório(vAl, TAM);
                
                cout<<"\nNúmero de oprações realizadas Algoritmo SelectionSort:";
                cout<<"\nVetor Crescente: "<<selectionsort(vCresc, TAM);
                cout<<"\nVetor Decrescente: "<<selectionsort(vDecresc, TAM);
                cout<<"\nVetor Aleatório: "<<selectionsort(vAl, TAM);
                break;
        }
    }while(x!=0);

    return 0;
}

