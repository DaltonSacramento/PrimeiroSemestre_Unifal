/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;
ifstream arquivoE("arquivo.txt");

/*
 * Função para apresentar o menu de escolha ao usuário
 */
int opçao(){
    int x;
    int resposta;
    
    //Menu
    cout<<"\n1 - BubbleSort";
    cout<<"\n2 - InsertionSort";
    cout<<"\n3 - SelectionSort";
    cout<<"\n0 - Sair"<<endl<<endl;
    cout<<"\nDigite a opção: ";
    cin>>resposta;
    //Mensagem caso a resposta não for válida
    while(resposta != 1 && resposta !=2 && resposta !=3 && resposta !=0){
        cout<<"\nValor inválido, digite novamente.";
        cout<<"\nDigite aqui um valor de 0 a 3: ";
        cin>>resposta;
    }
    cout<<endl;
    return resposta;
}

/*
 * Implementação do algoritmo bubblesort
 */
unsigned long int bubblesort(int vB[], int tam){
    int aux=0;
    int y;
    unsigned long long int ContadorBubble=0;
    
    
    //Ordenação
    arquivoE>>vB[tam];
    for(int i=(tam-1); i>=(tam-tam+1); i--){
        ContadorBubble++;
        for(y=0; y<=(i-1); y++){
            ContadorBubble++;
            if(vB[y]>vB[y+1]){
                ContadorBubble++;
                aux=vB[y];
                ContadorBubble++;
                vB[y]=vB[y+1];
                ContadorBubble++;
                vB[y+1]=aux;
                ContadorBubble++;
            }
        }
    }
    return ContadorBubble;
}

/*
 * Implementação do algoritmo insertionsort
 */
unsigned long long int insertionsort(int vI[], int tam){
    int aux=0;
    int y, MenorV, j;
    unsigned long long int ContadorInsertion=0;
    
    //Ordenação
    arquivoE>>vI[tam];
    for(int i=(tam-tam+1); i<=(tam-1); i++){
        ContadorInsertion++;
        aux=vI[i];
        ContadorInsertion++;
        j=(i-1);
        while((j>=0) && (vI[j]>aux)){
            ContadorInsertion++;
            vI[j+1]=vI[j];
            ContadorInsertion++;
            j=(j-1);
        }
        vI[j+1]=aux;
        ContadorInsertion++;
    }
    return ContadorInsertion;
}

/*
 * Implementação do algoritmo selectionsort
 */
unsigned long long int selectionsort(int vS[], int tam){
    int aux;
    int y, MenorV;
    int j;
    unsigned long long int ContadorSelection=0;
    
    //Ordenação
    arquivoE>>vS[tam];
    for(int i=(tam-tam); i<=(tam-1); i++){
        ContadorSelection++;
        MenorV=i;
        aux=vS[i];
        ContadorSelection++;
        for(j=i+1; j<=(tam-1); j++){
            ContadorSelection++;
            if(vS[j] < aux){
                ContadorSelection++;
                MenorV=j;
                aux=vS[j];
                ContadorSelection++;
            }
        }
        aux=vS[i];
        ContadorSelection++;
        vS[i]=vS[MenorV];
        ContadorSelection++;
        vS[MenorV]=aux;
        ContadorSelection++;
    }
    return ContadorSelection;
}
