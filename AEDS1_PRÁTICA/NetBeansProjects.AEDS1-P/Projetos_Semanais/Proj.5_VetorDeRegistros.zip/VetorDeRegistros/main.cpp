/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Dalton D'Angelis Sacramento
 * Created on 2 de maio de 2024, 16:38
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <fstream>

using namespace std;

/*
 * Este código foi desenvolvido na linguagem com o intuito de realizar 
 * operações em valores armazenados num vetor de registros, com variaveis
 * numericas e literais. Neste projeto o programador deve criar uma agenda de 
 * amigos, onde a mesma possui os dados nome, celular, cidade e email. 
 * Além disso, o projeto deve considerar no registro um campo especifico 
 * que indique se o registro é válido ou não, assim. No final das operações,
 * o codigo deve escrever a nova agenda em um vetor de saida.
 */

const int TAM = 100;

typedef struct{
    bool valido;
    string nome;
    string celular;
    string cidade;
    string email;
}Pessoas;


int main(int argc, char** argv) {
    
    ifstream arquivoE("Amigos.txt");
    
    Pessoas amigo;
    Pessoas agenda[TAM];
    int qtde = 0;
    int x, y, opçao, z, a;
    string NomeV, nome, NomeE;
    
    
    cout<<"\nDados de um amigo.\n";
    
    
    for(x=0; agenda[x-1].nome!="fim"; x++, qtde++){
        agenda[x].valido=true;
        arquivoE>>agenda[x].nome;
        cout<<"\nNome: "<<agenda[x].nome;
            if(agenda[x].nome!="fim"){
                arquivoE>>agenda[x].celular;
                cout<<"\nCelular: "<<agenda[x].celular;
                arquivoE>>agenda[x].cidade;
                cout<<"\nCity: "<<agenda[x].cidade;
                arquivoE>>agenda[x].email;
                cout<<"\nEmail: "<<agenda[x].email;
            }
    }
    
    
    
    cout<<"\n\nEscreva a operação que deseje fazer no vetor: ";
    cout<<"\n1 para vizualizar os dados de um amigo.";
    cout<<"\n2 para incluir um amigo.";
    cout<<"\n3 para excluir um amigo.";

    
    
    do{
        cout<<"\n\nDigite a opçao desejada aqui: ";
        cin>>opçao;
    switch(opçao){
        
        
        
        
        case 1:
            cout<<"\nDigite o nome do amigo que deseja vizualizar: ";
            cin>>NomeV;
            
            for(z=0, x=0; agenda[x-1].nome!="fim";){

                if(agenda[x].nome==NomeV){
                    if(agenda[x].valido==true){
                    z++;
                    }
                }
                if(agenda[x].nome==NomeV){
                    if(agenda[x].valido==true){
                        for(y=x; y<=x;){
                            cout<<"\nO nome do amigo é: "<<agenda[x].nome;
                            cout<<"\nO celular do  amigo é: "<<agenda[x].celular;
                            cout<<"\nA cidade do  amigo é: "<<agenda[x].cidade;
                            cout<<"\nO email do  amigo é: "<<agenda[x].email<<endl;
                            y++;
                        }
                    }
                }
                x++;
            }
            if(z==0){
                cout<<"\nO nome digitado nao existe ou foi excluido";
            }
            break;
        
        
            
            
        case 2:
            cout<<"\n\nAgora voce incluirá os dados de um novo amigo.";
            
            a=0;
            for(x=0; agenda[x-1].nome!="fim" || agenda[x].valido!=false;){
                if(agenda[x].nome=="fim" || agenda[x].valido==false){
                    for(a=x; a<=x;){
                        if(a<=x){
                            cout<<"\nDigite o nome do amigo ou digite fim "
                                    "para finalizar a inserçao de novos "
                                    "amigos: ";
                            cin>>nome;
                            if(nome!="fim"){
                                agenda[x].valido=true;
                                agenda[x].nome=nome;
                                cout<<"Digite o celular do amigo: ";
                                cin>>agenda[x].celular;
                
                                cout<<"Digite a cidade do amigo: ";
                                cin>>agenda[x].cidade;
                
                                cout<<"Digite o email do amigo: ";
                                cin>>agenda[x].email;
                                agenda[x+1].valido=true;
                                agenda[x+1].nome="fim";
                            }
                        }
                    a++;
                    }
                }
                x++;
            }
            break;
             
            
            
            
        case 3:
            cout<<"Digite o nome do amigo que deseja excluir: ";
            cin>>NomeE;
            
            for(x=0; agenda[x-1].nome!="fim";){
                if(agenda[x].nome==NomeE){
                    for(y=x; y<=x;){
                        agenda[x].valido=false;
                        cout<<"Amigo da posiçao "<<(x+1)<<"º foi excluido com "
                                "sucesso";
                        y++;
                    }
                }
                x++;
            }
            break;
        
        
           
            
      }
    }while(opçao!=0);
    
    
    ofstream arquivoS("Amigos.txt");
    for(x=0, y=0; agenda[x-1].nome!="fim"; x++){
        if(agenda[x].valido==true){
            arquivoS<<agenda[x].nome<<endl;
            if(agenda[x].nome!="fim"){
                arquivoS<<agenda[x].celular<<endl;
                arquivoS<<agenda[x].cidade<<endl;
                arquivoS<<agenda[x].email<<endl;  
            }
        }
    }

    
    return 0;
}

