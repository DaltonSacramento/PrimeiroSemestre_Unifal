/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Dalton D'Angelis Sacramento
 * RA: 2024.1.08.005
 * Created on 4 de junho de 2024, 16:14
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include "matriz.h"

using namespace std;

int opçao(){
    cout<<"\n";
    int x;
    int resposta;
    cout<<"\n1 - Trasposição";
    cout<<"\n2 - Soma";
    cout<<"\n3 - Multiplicação";
    cout<<"\n4 - Valor Médio";
    cout<<"\n0 - Sair"<<endl;
    
    cout<<"\nDigite a opção desejada: ";
    cin>>resposta;
    while(resposta != 1 && resposta !=2 && resposta !=3 && resposta !=4 && resposta !=0){
        cout<<"\nValor inválido, digite novamente.";
        cout<<"\nDigite aqui um valor de 0 a 4: ";
        cin>>resposta;
    }
    cout<<endl;
    
    return resposta;
}

/*
 * Função para exibir a matriz fornecida pelo usuário como argumento
 */
int exibiçao(TMatriz v, int L, int C){
    int x, y;
    
    for(x=0; x<L; x++){
        cout<<"\n";
        for(y=0; y<C; y++){
            cout << " "<<v[x][y];
        }
    }
    return 0;
}

/*
 * Este projeto foi criado na linguagem C/C++, e tem como objetivo ler 2 
 * matrizes com parâmetros fornecidos pelo usuário e realizar algumas operações
 * escrevendo o resultado em uma terceira matriz, para apresentar na tela. 
 * As operações disponíveis são:
 * 
 * Transposição de uma matriz;
 * Soma;
 * Multiplicação;
 * Cálculo do valor médio dos elementos da matriz.
 */
int main(int argc, char** argv) {
    //Indices
    int y, x;        
    //Parametros
    int L1, L2, Cl1, Cl2;
    //Variável de chegada do return
    int Retorno;
    //Valor Medio da matriz
    float ValorMedio;
    //Matrizes
    TMatriz v, v2, v3;
    
    //Geração da matriz 1
    cout<<"\nMatriz 1. ";
    cout<<"\nDigite o n° de linhas da matriz 1: ";
    cin>>L1;
    cout<<"\nDigite o n° de colunas da matriz 1: ";
    cin>>Cl1;
    for(x=0; x<L1; x++){
        for(y=0; y<Cl1; y++){
            cout <<"\nLinha-"<<x<<" Coluna-"<<y<<": ";
            cin>>v[x][y];
        }
    }
    
    //Geração da matriz 2
    cout<<"\nMatriz 2. ";
    cout<<"\nDigite o n° de linhas da matriz 2: ";
    cin>>L2;
    cout<<"\nDigite o n° de colunas da matriz 2: ";
    cin>>Cl2;
    cout <<"\nDigite os valores da matriz 2.";
    for(x=0; x<L2; x++){
        for(y=0; y<Cl2; y++){
            cout <<"\nLinha-"<<x<<" Coluna-"<<y<<": ";
            cin>>v2[x][y];
        }
    }
    
    //Switch case
    do{
        switch(y=opçao()){
        
            //Transposta
            case 1:
                transposta(v3,v,L1,Cl1);
                cout<<"\nMatriz 1 transposta: ";
                exibiçao(v3,Cl1,L1);
                
                transposta(v3,v2,L2,Cl2);
                cout<<"\nMatriz 2 transposta: ";
                exibiçao(v3,Cl2,L2);
                break;
               
            //Soma    
            case 2:
                Retorno = soma(v3,v2,v,L1,Cl1,L2,Cl2);
                if(Retorno==0){
                    cout<<"\nMatriz Soma: ";
                    exibiçao(v3,L1,Cl1);
                }
                break;
  
            //Multiplicação    
            case 3:
                Retorno = multiplicaçao(v3,v,v2,L1,Cl1,L2,Cl2);
                if(Retorno==0){
                    cout<<"\nMatriz Produto: ";
                    exibiçao(v3,L1,Cl2); 
                }
                break;
            
            //Valor médio    
            case 4:
                ValorMedio = valormedio(v,L1,Cl1);
                cout<<"\nO valor medio da matriz 1 é: "<<(ValorMedio/(L1*Cl1));
                ValorMedio = valormedio(v2,L2,Cl2);
                cout<<"\nO valor medio da matriz 2 é: "<<(ValorMedio/(L2*Cl2));
                break;
            
        }
    }while(y!=0);
    
    return 0;
}

