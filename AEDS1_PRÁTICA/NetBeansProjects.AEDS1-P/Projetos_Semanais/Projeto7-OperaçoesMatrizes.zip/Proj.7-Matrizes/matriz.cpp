/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include "matriz.h"

using namespace std;

/*
 * Função para calcular a soma entre duas matrizes fornecidas pelo usuário
 */
int soma(TMatriz v3, TMatriz v, TMatriz v2, int L1, int Cl1, int L2, int Cl2){
    int y, x;
    
    if(L1==L2 && Cl1==Cl2){
        //SOMA
        for(x=0; x<L1; x++){
            for(y=0; y<Cl1; y++){
                v3[x][y]=v[x][y]+v2[x][y];
            }
        }
        return 0;
    }
    else{
        cout<<"\nSoma impossível. Matrizes de ordem diferente.";
        return 1;
    }
    cout<<endl;
}

/*
 * Função para calcular uma matriz produto entre duas matrizes fornecidas pelo
 * usuário
 */
int multiplicaçao(TMatriz v3, TMatriz v, TMatriz v2, int L1, int Cl1, int L2, int Cl2){
    int y, x, z;
    int Soma=0;
    
    if(Cl1==L2){
        //Multiplicação
        for(x=0; x<L1; x++){
            for(y=0; y<Cl2; y++){
                for(z=0; z<L2; z++){
                Soma=Soma+(v[x][z]*v2[z][y]);
                }
                v3[x][y]=Soma;
                Soma=0;
            }
        }
        return 0;
    }
    else{
        cout<<"\nMultiplicação impossível.";
        return 1;
    }
    cout<<endl;
}

/*
 * Função para calcular a matriz transposta da matriz inserida pelo usuário
 */
int transposta(TMatriz v3, TMatriz v, int L, int C){
    int y, x;
    //Transposição
    for(x=0; x<L; x++){
        for(y=0; y<C; y++){
            v3[y][x]=v[x][y];
        }
    }
    return 0;
    cout<<endl;
}

/*
 * Função para calcular o valor médio dos elementos da matriz
 */
int valormedio(TMatriz v, int L, int C){
    int y, x;
    float Soma=0;
    //Soma para o cálculo do valor médio
    for(x=0; x<L; x++){
        for(y=0; y<C; y++){
            Soma=Soma+v[x][y];
        }
    }
    return Soma;
    cout<<endl;
}


