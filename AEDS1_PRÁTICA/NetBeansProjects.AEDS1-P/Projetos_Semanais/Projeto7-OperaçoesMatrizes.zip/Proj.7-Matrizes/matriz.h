/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Dalton D'Angelis Sacramento
 * RA: 2024.1.08.005
 * Created on 4 de junho de 2024, 16:14
 */

#ifndef MATRIZ_H
#define MATRIZ_H

typedef int TMatriz[10][10];

int soma(TMatriz v3, TMatriz v, TMatriz v2, int L1, int Cl1, int L2, int Cl2);

int multiplicaçao(TMatriz v3, TMatriz v, TMatriz v2, int L1, int Cl1, int L2, int Cl2);

int transposta(TMatriz v3, TMatriz v, int L, int C);

int valormedio(TMatriz v, int L, int C);

#endif /* MATRIZ_H */

