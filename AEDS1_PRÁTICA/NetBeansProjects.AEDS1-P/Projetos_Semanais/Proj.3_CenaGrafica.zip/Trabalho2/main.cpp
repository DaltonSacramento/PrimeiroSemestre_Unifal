/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   Trabalho_CenaGrafica
 * Author: Dalton D'Angelis Sacramento
 * Created on 4 de abril de 2024, 13:40
 */

#include <cstdlib>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <math.h>

using namespace std;

/*
 * Este projeto é um programa feito em C++ qeu visa ler um arquivo de texto
 * com que apresenta informações sobre alguns objetos geométricos 2Ds e 3Ds,
 * e com as medidas dos sólidos, o programa cálcula a area e o volume dos
 * mesmos, por conseguinte, no final da execução o programa exibe na tela
 * a soma de todas as areas e todos os volumes cálculados durante o processo.
 */

int main(int argc, char** argv) {
    
    float lado, volume, area, altura, raio, lado2, lado3, base, G, AreaTotal,
            VolumeTotal;
    string objeto;
    
    ifstream arquivo("cenagrafica.txt");
    
    AreaTotal=0;
    VolumeTotal=0;
    objeto="início";
    while(objeto != "fim"){
        arquivo>>objeto;
        AreaTotal=AreaTotal+area;
        VolumeTotal=VolumeTotal+volume;

        
        if(objeto == "cubo"){
            arquivo>>lado;
            volume=lado*lado*lado;
            area=lado*lado*6;
            cout<<"\nA área do cubo é: "<<area<<"cm²";
            cout<<"\nO volume do cubo é: "<<volume<<"cm³";
            cout<<"\n----------------------------------------------";
        }
        
        if(objeto == "quadrado"){
            arquivo>>lado;
            area=lado*lado;
            volume=0;
            cout<<"\nA area do quadrado é: "<<area<<"cm²";
            cout<<"\n----------------------------------------------";
        }
        
        if(objeto == "esfera"){ 
            arquivo>>raio; 
            area=4*3.14*raio*raio;    
            volume=(4*3.14*(raio*raio*raio))/3;  
            cout<<"\nA area da esfera é: "<<area<<"cm²";   
            cout<<"\nO volume da esfera é: "<<volume<<"cm³";       
            cout<<"\n----------------------------------------------";
        }
        
        if(objeto == "circulo"){
            arquivo>>raio;
            area=3.14*raio*raio;
            volume=0;
            cout<<"\nA area do circulo é: "<<area<<"cm²";
            cout<<"\n----------------------------------------------";
        }
     
        if(objeto == "retangulo"){
            arquivo>>lado;
            arquivo>>lado2;
            area=lado*lado2;
            volume=0;
            cout<<"\nA area do retangulo é: "<<area<<"cm²";
            cout<<"\n----------------------------------------------";
        }
        
        if(objeto == "paralelepípedo"){
            arquivo>>lado;
            arquivo>>lado2;
            arquivo>>lado3;
            area=(lado*lado2)*2+(lado2*lado3)*2+(lado*lado3)*2;
            volume=lado*lado2*lado3;
            cout<<"\nA area do paralelepipedo é: "<<area<<"cm²";
            cout<<"\nO volume do paralelepipedo é: "<<volume<<"cm³";
            cout<<"\n----------------------------------------------";
        }
        
        if(objeto == "cilindro"){
            arquivo>>raio;
            arquivo>>altura;
            volume=(3.14*raio*raio)*altura;
            area=0;
            cout<<"\nO volume do cilindro é: "<<volume<<"cm³";
            cout<<"\n----------------------------------------------";
        }
        
        if(objeto == "cone"){
            arquivo>>raio;
            arquivo>>altura;
            G=raio*raio+altura*altura;/*geratriz*/
            volume=((3.14*raio*raio)*altura)/3;
            area=3.14*raio*raio + 3.14*raio*sqrt(G);
            cout<<"\nA area do cone é: "<<area<<"cm²";
            cout<<"\nO volume do cone é: "<<volume<<"cm³";
            cout<<"\n----------------------------------------------";
        }
        
        if(objeto == "triangulo"){
            arquivo>>base;
            arquivo>>altura;
            area=(base*altura)/2;
            volume=0;
            cout<<"\nA area do triangulo é: "<<area<<"cm²";
            cout<<"\n----------------------------------------------";
        }
        
    }
    cout<<"\nA área total da cena grafica é: "<<AreaTotal<<"cm²";
    cout<<"\nO volume total da cena grafica é: "<<VolumeTotal<<"cm³";
    

    return 0;
}

