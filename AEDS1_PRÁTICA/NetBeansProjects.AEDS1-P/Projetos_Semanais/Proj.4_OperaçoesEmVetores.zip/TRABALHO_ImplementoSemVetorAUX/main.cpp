/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   TRABALHO_OperaçõesEmVetores
 * Author: Dalton D'Angelis Sacramento
 * Created on 18 de abril de 2024, 14:43
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <stdio.h>
#include <math.h>

using namespace std;

/*
 * Este código foi criado na linguagem c++ com intuito de criar um programa que
 * faça algumas operações em um vetor, o mesmo gera 1000 numeros de 10 a 200 e
 * por meio de um menu, fazer com que o usuario digite qual opção das 6 
 * existentes ele deseja que o codigo execute. Dentre essas opções estão:
 * 
 * 1.Buscar pela primeira ocorrência de um valor;
 * 2.Busca para contar a quantidade de ocorrências que um valor aparece;
 * 3.Busca para contar a quantidade de ocorrências de valores de um intervalo;
 * 4.Inverter os valores de um vetor;
 * 5.Excluir um valor informado pelo usuário deslocando os valores para à esquerda;
 * 6.Retirar todos os valores repetidos;
 * 
 */
int main(int argc, char** argv) {
    
    int x, y, z, a, b, out, c;
    float valor, InicioIntervalo, FimIntervalo;
    float numero[1000];
    int opção;
    
    
    srand(time(NULL));
    
    
    cout<<"\n\nDIGITE";
    cout<<"\n1 Para buscar pela primeira ocorrencia de um valor.";
    cout<<"\n2 Para contar a quantidade de ocorrencias de um valor.";
    cout<<"\n3 Para contar a quantidade de ocorrencias dos valores de um intervalo";
    cout<<"\n4 Para inverter os valores de um vetor.";
    cout<<"\n5 Para retirar do vetor todas as ocorrencas de um valor escolhido.";
    cout<<"\n6 Para retirar de um vetor todos os valores repetidos.";
    
    
   for(x=0; x<1000; x++){
        numero[x]= 10+rand()%191;
        }
    cout<<"\n\nOs valores do vetor são:\n";
    for(x=0; x<1000; x++){
        cout<<"<>"<<numero[x]; 
    }
        /*O simbolo "<>" foi usado para a separação dos                
         * e a consequente melhora na visualização da                  
         * posição dos mesmos.
         */
        
    
    
    do{
        cout<<"\n\nDigite aqui a opção desejada: ";
        cin>>opção;
        while(opção<0 || opção>6){
            cout<<"\nValor incorreto. Digite novamente: ";
            cin>>opção;
        }
        
        switch(opção){
            
            
            
            
            case 1:
                cout<<"\nDigite um valor de 10 a 200 que deseje saber se "
                        "existe e qual sua posição: ";
                cin>>valor;
                
                y=0;
                z=0;
                for(x=0; x<1000; x++){ 
                    if(numero[x]==valor){
                        y++;
                        if(y==1){
                            cout<<"\nO valor digitado EXISTE no vetor.";
                        }
                        cout<<"\nSua 1º posição entre os mil numeros é: "
                                ""<<x<<"º";
                        break;
                    }
                    else{
                        z++;
                        if(z==1000){
                            cout<<"\nO valor digitado NAO EXISTE no vetor.";
                        }
                    }
                }
                break;
                
                
                
                
            case 2:
                cout<<"\nDigite um valor de 10 a 200 que voce deseje saber "
                        "quantas vezes aparece no vetor e quais suas posições: ";
                cin>>valor;
                
                y=0;
                for(x=0; x<1000; x++){ 
                    if(numero[x]==valor){
                        y++;
                        cout<<"\nSua "<<y<<"º posição entre os mil numeros é: "
                                ""<<x<<"º";
                    }
                }
                cout<<"\nO valor digitado aparece "<<y<<" vezes no vetor.";
                break;
                
               
                
                
            case 3:
                cout<<"\nDigite um intervalo de 10 a 200 que deseje descobrir "
                        "quantas vezes aparece no vetor.";
                cout<<"\nO intervalo iniciará no numero: ";
                cin>>InicioIntervalo;
                cout<<"E terminará no numero: ";
                cin>>FimIntervalo;
                
                y=0;
                for(x=0; x<1000; x++){ 
                    if(numero[x]>=InicioIntervalo && numero[x]<=FimIntervalo){
                        y++;
                    }
                }
                cout<<"\nOs valores do intervalo aparecem no vetor "<<y<<""
                            " vezes.";
                break;
                
                
                
                
            case 4:
                y=0;
                out=0;
                z=1000;
                for(x=0; x<500; x++){
                    z=z-1;
                    out=numero[x];
                    numero[x]=numero[z];
                    numero[z]=out;
                }
                cout<<"PRONTO!!!";
                cout<<"\nOs valores do vetor foram invertidos com sucesso.\n";
                for(x=0; x<1000; x++){
                    cout<<"<>"<<numero[x];
                }
                break;
                
                
                
                
            case 5:
                cout<<"\nDigite qual valor deseja eliminar do vetor: ";
                cin>>valor;
                
                y=0;
                for(x=0; x<1000; x++){
                    if(numero[x]==valor){
                        y++;
                    }
                }
                if(y==0){
                    while(y==0){
                        cout<<"\nO valor nao existe.";
                        cout<<"\nDigite novamente: ";
                        cin>>valor;
                        for(x=0; x<1000; x++){
                            if(numero[x]==valor){
                                y++;
                            }
                        }
                    }
                }   
                a=0;
                b=0;
                for(x=0; x<1000; x++){
                    if(numero[x]==valor){
                        b=x;
                        a++;
                        for(z=x+1; z<1000; z++){ 
                           numero[b]=numero[z];
                           b++;
                        }
                        x=x-1;
                    }
                }
                cout<<"PRONTO!!!";
                cout<<"\nO valor digitado foi eliminado com sucesso.\n";
                for(x=0; x<1000-a; x++){
                    cout<<"<>"<<numero[x];
                }
                break;
                
                
                
                
            case 6:
                b=0;
                c=0;
                for (int x = 0; x<1000; x ++){
                        for (int z = x + 1; z < 1000; z++){
                            if(numero[x] == numero[z]){ 
                                c++;
                                for (int b = z; b < 1000; b++){
                                    numero[b] = numero[b+1];
                                }
                                z==x;
                            }
                        }
                }
                cout<<"PRONTO!!!";
                cout<<"\nOs valores repetidos foram retirados com sucesso.\n";
                for(x=0; x<1000-c; x++){
                    cout<<"<>"<<numero[x];
                }
                break;
                
                
                
                
        }
    } while(opção!=0);
            
    return 0;
}

