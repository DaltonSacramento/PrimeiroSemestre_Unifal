/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   Trabalho_Triângulos
 * Author: Dalton D'Angelis Sacramento
 * Created on 12 de março de 2024, 22:39
 */

#include <cstdlib>
#include <stdio.h>
#include <iostream>
#define LA L1*L1+L2*L2==L3*L3
#define LB L1*L1+L3*L3==L2*L2
#define LC L2*L2+L3*L3==L1*L1

using namespace std;

/*
 * Este é um trabalho que busca informar ao usuário algumas categorias e
 * classificações dos triângulos, o código foi escrito na linguagem C++
 * usando as informações ensinadas nas aulas práticas pelo
 * professor Paulo Bressan.
 */
int main(int argc, char** argv) {
    
    float L1, L2, L3;
    
    cout<<"\nDigite a medida de um lado do triangulo: ";
    cin>>L1;
    while(L1<=0){
        cout<<"\nA medida informada precisa ser positiva. Digite novamente: ";
        cin>>L1;
    }

    
    cout<<"Digite a medida do segundo lado do triangulo: ";
    cin>>L2;
    while(L2<=0){
        cout<<"\nA medida informada precisa ser positiva. Digite novamente: ";
        cin>>L2;
    }

    
    cout<<"Digite a medida do terceiro lado do triangulo: ";
    cin>>L3;
    while(L3<=0){
        cout<<"\nA medida informada precisa ser positiva. Digite novamente: ";
        cin>>L3;
    }

    
    if(L1+L2<=L3 || L1+L3<=L2 || L2+L3<=L1){
        cout<<"\nO triângulo especificado não existe.";
    }  
    else{  
        cout<<"\nO triângulo especificado existe.";
      if(L1==L2 && L2==L3){    
          cout<<"\nO triângulo é equilátero.";
      }
      else{
        if(L1==L2||L1==L3||L2==L3){   
            cout<<"\nO triângulo é isósceles.";
        }
        else{ 
              cout<<"\nO triângulo é escaleno.";
        }
      }
          if(LA||LB||LC){
          cout<<"\nO triângulo especificado é retângulo.";
          }
          else{
          cout<<"\nO triângulo especificado não é retangulo.";
          }
    }

return 0;
}


