
/* 
 * File:   Estatística em Base de Dados de Veículos
 * Author: Dalton D'Angelis Sacramento
 * Created on 6 de maio de 2024, 18:47
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <fstream>
#include <limits>
#include <cctype>
#define PRESTAÇAO VeiculoMB*(0.02/(1-pow(1.02,-60)))

using namespace std;

/*
 * 
 */

//Tamanho do banco de dados
const int TAM = 100;

//Campos do Registro
typedef struct{
    bool valido;
    string modelo;
    string marca;
    string tipo;
    int ano;
    int quilometragem;
    string potencia_do_motor;
    string combustivel;
    string cambio;
    string direçao;
    string cor;
    string portas;
    string placa;
    float valor;
}Carros;

int main(int argc, char** argv) {
    
    //Comando para atribuir ao arquivo de texto o status de arquivo de leitura
    ifstream arquivoE("ArquivoVeículos.txt");
    
    //VARIÁVEIS
    //Vetor
    Carros BancodeDados;
    Carros BD[TAM];
    //Variável para receber o campo modelo do vetor
    string modelo;
    //Variáveis de entrada do caso 2
    string PlacaB, RespostaE;
    //Variável de entrada do caso 3
    string TipoB;
    //Variável de entrada do caso 4
    string CambioB;
    //Quantidade de veículos
    int qtde = 0;
    //Contadores diversos
    int x, y, z, a;
    //Opção de escolha do menu
    int opçao;
    //Variáveis de entrada do caso 5
    int Ifaixa, Ffaixa;
    
    //RELATÓRIO
    //Porcentagens de cada tipo de carro
    float PHatch, PSUV, PPickup, PSedã, PVan;
    //Porcentagens de cada combustível
    float PAlcool, PGasolina, PDiesel, PFlex;
    //Variáveis para cálculo do veículo de menor valor
    double VeiculoMB;
    float Valor;
    string ModeloMB;
    string PlacaVMB;
    //Variáveis para cálculo do veículo de maior valor
    float VeiculoMC;
    string ModeloMC;
    string PlacaVMC;
    float SeguroAnual;
    //Variáveis para os cálculos relacionados a quilometragem
    float MediaKM;
    int QTDEAno;
    
    //TÍTULO
    cout<<"\n----------------Banco de Dados para veículos------------------\n";
    
    //Leitura do arquivo de texto de entrada
    for(x=0; modelo!="FIM";){
        arquivoE>>modelo;
        if(modelo!="FIM"){
            BD[x].valido=true;           
            BD[x].modelo=modelo;
            arquivoE>>BD[x].marca;            
            arquivoE>>BD[x].tipo;  
            arquivoE>>BD[x].ano;     
            arquivoE>>BD[x].quilometragem; 
            arquivoE>>BD[x].potencia_do_motor;         
            arquivoE>>BD[x].combustivel;            
            arquivoE>>BD[x].cambio;     
            arquivoE>>BD[x].direçao;
            arquivoE>>BD[x].cor;     
            arquivoE>>BD[x].portas;         
            arquivoE>>BD[x].placa;         
            arquivoE>>BD[x].valor;
            qtde++;
        }
        x++;
    }
    
    
    //MENU DE ESCOLHA
    cout<<"\nMENU DE ESCOLHA.\n";
    cout<<"\nDigite um número:";
    cout<<"\n1:  Inclusão de um novo veículo na base de dados.";
    cout<<"\n2:  Busca de um veículo pela placa, com opção de exclusão do banco "
                "de dados.";
    cout<<"\n3:  Busca de veículos pelo tipo.";
    cout<<"\n4:  Busca de veículos pelo câmbio.";
    cout<<"\n5:  Busca de veículos por uma faixa de valores.";
    cout<<"\n6:  Vizualização do relatório do banco de dados.";
    cout<<"\n0:  Finalizar.";
            

    //Repetição para análise da opçao escolhida no menu
    do{
        cout<<"\n\nDigite qual opção do MENU deseja selecionar: ";
        cin>>opçao;
        //Switch case
    switch(opçao){
        
        
        
        //Caso para adição de um novo veículo
        case 1:
            
            //Condição para inserção de novo veículo, somente se houver espaço
            if(qtde<100){
                //Verificação se existe algum veículo inválido no vetor
                for(x=0, z=0; x<qtde;){
                    if(BD[x].valido==false){
                        z=x;
                    }
                    x++;
                }
                //Inserção de novo veículo numa nova posição
                if(z==0){
                    cout<<"\nAgora irá incluir um novo veículo.";
                    cout<<"\nDigite as informações:"; 
                    BD[x].valido=true;
                    cout<<"\nModelo do veículo: ";
                    cin>>BD[x].modelo;            
                    cout<<"Marca do veículo: ";
                    cin>>BD[x].marca;           
                    cout<<"Tipo do veículo: ";
                    cin>>BD[x].tipo;           
                    cout<<"Ano do veículo: ";
                    cin>>BD[x].ano;             
                    cout<<"Quilometragem do veículo: ";
                    cin>>BD[x].quilometragem;          
                    cout<<"Potência do motor do veículo: ";
                    cin>>BD[x].potencia_do_motor;           
                    cout<<"Tipo de combustivel do veículo: ";
                    cin>>BD[x].combustivel;            
                    cout<<"Tipo de câmbio do veículo: ";
                    cin>>BD[x].cambio;                            
                    cout<<"Tipo de direção do veículo: ";
                    cin>>BD[x].direçao;                          
                    cout<<"Cor do veículo: ";
                    cin>>BD[x].cor;               
                    cout<<"Quantidade de portas do veículo: ";
                    cin>>BD[x].portas;                         
                    cout<<"Placa do veículo: ";
                    cin>>BD[x].placa;                         
                    cout<<"Valor do veículo: ";
                    cin>>BD[x].valor;
                    qtde++;
                }
                //Inserção de novo veículo no lugar de um inválido
                else{
                    cout<<"\nAgora irá incluir um novo veículo.";
                    cout<<"\nDigite as informações:"; 
                    BD[z].valido=true;
                    cout<<"\nModelo do veículo: ";
                    cin>>BD[z].modelo;            
                    cout<<"Marca do veículo: ";
                    cin>>BD[z].marca;           
                    cout<<"Tipo do veículo: ";
                    cin>>BD[z].tipo;           
                    cout<<"Ano do veículo: ";
                    cin>>BD[z].ano;             
                    cout<<"Quilometragem do veículo: ";
                    cin>>BD[z].quilometragem;          
                    cout<<"Potencia do motor do veículo: ";
                    cin>>BD[z].potencia_do_motor;           
                    cout<<"Tipo de combustivel do veículo: ";
                    cin>>BD[z].combustivel;            
                    cout<<"Tipo de câmbio do veículo: ";
                    cin>>BD[z].cambio;                            
                    cout<<"Tipo de direção do veículo: ";
                    cin>>BD[z].direçao;                          
                    cout<<"Cor do veículo: ";
                    cin>>BD[z].cor;               
                    cout<<"Quantidade de portas do veículo: ";
                    cin>>BD[z].portas;                         
                    cout<<"Placa do veículo: ";
                    cin>>BD[z].placa;                         
                    cout<<"Valor do veículo: ";
                    cin>>BD[z].valor;
                    }
            }
            else{
            //Mensagem caso aconteça do banco de dados estar cheio
                cout<<"\nA quantidade de veículo já limitou a capacidade do"
                        " banco de dados.";
            }
            break;
            
        //Busca de um veículo pela placa, com opção de exclusão  
        case 2:
            cout<<"\nAgora vocẽ irá buscar um veículo pela placa.";
            cout<<"\nDigite a placa do veículo desejado: ";
            cin>>PlacaB;
            //Repetição para análise de placas
            for(a=1, y=0, z=0, x=0; x<qtde;){
                //Contador para quantidade de placas iguais à digitada
                if(BD[x].placa==PlacaB){
                    if(BD[x].valido==true){
                        z++;
                    }
                }
                if(BD[x].placa==PlacaB){
                    if(BD[x].valido==true){
                        //Repetição para vizualização dos dados do veículo
                        for(y=x; y<=x;){
                            cout<<"\nDados do veículo da "<<a<<"º posição.";
                            cout<<"\nModelo: "<<BD[x].modelo;
                            cout<<"\nMarca: "<<BD[x].marca;              
                            cout<<"\nTipo: "<<BD[x].tipo;            
                            cout<<"\nAno: "<<BD[x].ano;                
                            cout<<"\nKM: "<<BD[x].quilometragem<<"km";          
                            cout<<"\npostencia: "<<BD[x].potencia_do_motor;            
                            cout<<"\nCombustivel: "<<BD[x].combustivel;               
                            cout<<"\nCâmbio: "<<BD[x].cambio;               
                            cout<<"\nDireção: "<<BD[x].direçao;               
                            cout<<"\nCor: "<<BD[x].cor;                
                            cout<<"\nPortas: "<<BD[x].portas;                
                            cout<<"\nPlaca: "<<BD[x].placa;
                            cout<<"\nValor: R$"<<BD[x].valor<<endl;
                            y++;
                        }
                    }
                }
                x++;
                a++;
            }
            //Mensagem caso aconteça de não existir nenhuma placa igual a 
            //digitada
            if(z==0){
                cout<<"\nA placa digitada não existe ou foi excluida";
                cout<<"\nPor favor, verifique se escreveu a placa "
                        "corretamente.";
            }
            //Exclusão de veículo
            //Pergunta ao usuário, se ele deseja excluir o veículo
            else{
                cout<<"\nVoce deseja excluir o carro analisado? Digite sim ou "
                        "nao: ";
                cin>>RespostaE;
                //Condiçao para resposta do usuário
                if(RespostaE=="sim" || RespostaE=="Sim"){
                    for(x=0; x<qtde;){
                        //Exclusão
                        if(BD[x].placa==PlacaB){                       
                            BD[x].valido=false;
                        }
                        x++;
                    }
                    cout<<"\nO veículo foi excluido da base de dados.";
                }
            }
            break;          
            
        //Busca de um veículo pelo tipo    
        case 3:
            //Pergunta sobre o tipo desejado
            cout<<"\nAgora voce irá buscar veículos pelo tipo (Hatch, Sedã, "
                    "Van, Pick-up ou SUV).";
            cout<<"\nDigite o tipo dos veículos desejado: ";
            cin>>TipoB;
            //Repetição para análise do tipo
            for(a=1, y=0, z=0, x=0; x<qtde; a++){
                if(BD[x].tipo==TipoB){
                    //Contador de quantidade de carros com o tipo igual ao
                    //digitado
                    if(BD[x].valido==true){
                        z++;
                    }
                }
                //Visualização dos dados dos veículos com o mesmo tipo do 
                //digitado
                if(BD[x].tipo==TipoB){
                    if(BD[x].valido==true){
                        for(y=x; y<=x;){
                            cout<<"\nDados do veículo da "<<a<<"º posição.";
                            cout<<"\nModelo: "<<BD[x].modelo;
                            cout<<"\nMarca: "<<BD[x].marca;              
                            cout<<"\nTipo: "<<BD[x].tipo;            
                            cout<<"\nAno: "<<BD[x].ano;                
                            cout<<"\nKM: "<<BD[x].quilometragem<<"km";          
                            cout<<"\npostencia: "<<BD[x].potencia_do_motor;            
                            cout<<"\nCombustivel: "<<BD[x].combustivel;               
                            cout<<"\nCâmbio: "<<BD[x].cambio;               
                            cout<<"\nDireção: "<<BD[x].direçao;               
                            cout<<"\nCor: "<<BD[x].cor;                
                            cout<<"\nPortas: "<<BD[x].portas;                
                            cout<<"\nPlaca: "<<BD[x].placa;
                            cout<<"\nValor: R$"<<BD[x].valor<<endl;
                            y++;
                        }
                    }
                }
                x++;
            }
            //Mensagem caso não exista nenhum carro com o tipo igual ao digitado
            if(z==0){
                cout<<"\nO tipo de veículo digitado não existe ou foi excluido";
                cout<<"\nPor favor, verifique se escreveu o tipo "
                        "corretamente.";
            }
            break;
        
            
        //Busca de veículos pelo câmbio
        case 4:
            //Pergunta ao usuário
            cout<<"\nAgora voce irá buscar veículos pelo câmbio (Automático ou "
                    "Manual).";
            cout<<"\nDigite o câmbio dos veículos desejado: ";
            cin>>CambioB;
            //Repetição para análise de resposta
            for(a=1, y=0, z=0, x=0; x<qtde; a++){
                if(BD[x].cambio==CambioB){
                    if(BD[x].valido==true){
                        z++;
                    }
                }
                //Vizualização dos dados dos carros com o câmbio igual ao 
                //digitado
                if(BD[x].cambio==CambioB){
                    if(BD[x].valido==true){
                        for(y=x; y<=x;){
                            cout<<"\nDados do veículo da "<<a<<"º posição.";
                            cout<<"\nModelo: "<<BD[x].modelo;
                            cout<<"\nMarca: "<<BD[x].marca;              
                            cout<<"\nTipo: "<<BD[x].tipo;            
                            cout<<"\nAno: "<<BD[x].ano;                
                            cout<<"\nKM: "<<BD[x].quilometragem<<"km";          
                            cout<<"\npostencia: "<<BD[x].potencia_do_motor;            
                            cout<<"\nCombustivel: "<<BD[x].combustivel;               
                            cout<<"\nCâmbio: "<<BD[x].cambio;               
                            cout<<"\nDireção: "<<BD[x].direçao;               
                            cout<<"\nCor: "<<BD[x].cor;                
                            cout<<"\nPortas: "<<BD[x].portas;                
                            cout<<"\nPlaca: "<<BD[x].placa;
                            cout<<"\nValor: R$"<<BD[x].valor<<endl;
                            y++;
                        }
                    }
                }
                x++;
            }
            //Mensagem caso não exista nenhum carro com o câmbio igual ao 
            //digitado
            if(z==0){
                cout<<"\nO tipo de câmbio digitado não existe ou foi excluido";
                cout<<"\nPor favor, verifique se escreveu o câmbio "
                        "corretamente.";
            }      
            break;
            
        //Busca de veículos em uma faixa de valores
        case 5:
            //Pergunta ao usuário
            cout<<"\nAgora voce irá buscar veículo por uma faixa de valores.";
            cout<<"\nDigite a faixa de valores desejada: ";
            cout<<"\nOs valores dos carros desejados irá de: ";
            //Início da faixa de valores
            cin>>Ifaixa;
            cout<<"Até o valor de: ";
            //Final da faixa de valores
            cin>>Ffaixa;
            //Repetição para análise dos carros dentro da faixa de valores 
            //digitada
            for(a=1, y=0, z=0, x=0; x<qtde; a++){
                //Contador para a quantidade de carros dentro da faixa de valores
                if(BD[x].valor >= Ifaixa && BD[x].valor <= Ffaixa){
                    if(BD[x].valido==true){
                        z++;
                    }
                }
                //Vizualização dos dados dos carros dentro da faixa de valores
                if(BD[x].valor >= Ifaixa && BD[x].valor <= Ffaixa){
                    if(BD[x].valido==true){
                        for(y=x; y<=x;){
                            cout<<"\nDados do veículo da "<<a<<"º posição.";
                            cout<<"\nModelo: "<<BD[x].modelo;
                            cout<<"\nMarca: "<<BD[x].marca;              
                            cout<<"\nTipo: "<<BD[x].tipo;            
                            cout<<"\nAno: "<<BD[x].ano;                
                            cout<<"\nKM: "<<BD[x].quilometragem<<"km";          
                            cout<<"\npostencia: "<<BD[x].potencia_do_motor;            
                            cout<<"\nCombustivel: "<<BD[x].combustivel;               
                            cout<<"\nCâmbio: "<<BD[x].cambio;               
                            cout<<"\nDireção: "<<BD[x].direçao;               
                            cout<<"\nCor: "<<BD[x].cor;                
                            cout<<"\nPortas: "<<BD[x].portas;                
                            cout<<"\nPlaca: "<<BD[x].placa;
                            cout<<"\nValor: R$"<<BD[x].valor<<endl;
                            y++;
                        }
                    }
                }
                x++;
            }
            //Mensagem caso não exista nenhum carro dentro da faixa de valores
            if(z==0){
                cout<<"\nNão existem veiculos que estão nesta faixa de "
                        "valores.";
            }
            break;
            
        //Relatório do banco de dados    
        case 6:
            //Cálculo da porcentagem de tipos, Hatch, SUV, Pick-up e Sedã
            //Contadores dos tipos
            PHatch=0;
            PSUV=0;
            PPickup=0;
            PSedã=0;
            PVan=0;
            //Repetição para contar os tipos
            for(x=0, y=0; x<qtde;){
                if(BD[x].valido==true){
                    if(BD[x].tipo=="Hatch"){
                            PHatch++;
                    }
                    if(BD[x].tipo=="SUV"){
                            PSUV++;
                    }
                    if(BD[x].tipo=="Pick-up"){
                            PPickup++;
                    }
                    if(BD[x].tipo=="Sedã"){
                            PSedã++;
                    }
                    if(BD[x].tipo=="Van"){
                            PVan++;
                    }
                }
                x++;
                
            }
            //Exibição e cálculo da porcentagem de cada tipo
            cout<<"\n\nPorcentagens de veículos nas categorias de tipo.";
            cout<<"\nHatch: "<<(PHatch/qtde)*100<<"%";
            cout<<"\nSUV: "<<(PSUV/qtde)*100<<"%";
            cout<<"\nPick-up: "<<(PPickup/qtde)*100<<"%";
            cout<<"\nSedã: "<<(PSedã/qtde)*100<<"%";
            cout<<"\nVan: "<<(PVan/qtde)*100<<"%";
            
            //------------------------------------------------------------------
            //Porcentagem de veículos pelo combustível
            //Contadores dos tipos de combustível
            PAlcool=0;
            PGasolina=0;
            PDiesel=0;
            PFlex=0;
            //Repetição para contar os tipos de combustíveis
            for(x=0, y=0; x<qtde;){
                if(BD[x].valido==true){
                    if(BD[x].combustivel=="Alcool"||BD[x].combustivel=="alcool"){
                        PAlcool++;
                    }
                    if(BD[x].combustivel=="Gasolina"||BD[x].combustivel=="gasolina"){
                        PGasolina++;
                    }
                    if(BD[x].combustivel=="Diesel"||BD[x].combustivel=="diesel"){
                        PDiesel++;
                    }
                    if(BD[x].combustivel=="Flex"||BD[x].combustivel=="flex"){
                        PFlex++;
                    }
                }
                x++;
            }
            //Exibição e cálculo da porcentagem dos tipos de combustíveis
            cout<<"\n\nPorcentagens de veículos nas categorias de combustível.";
            cout<<"\nAlcool: "<<(PAlcool/qtde)*100<<"%";
            cout<<"\nGasolina: "<<(PGasolina/qtde)*100<<"%";
            cout<<"\nDiesel: "<<(PDiesel/qtde)*100<<"%";
            cout<<"\nFlex: "<<(PFlex/qtde)*100<<"%";
            
            //------------------------------------------------------------------
            //Placa e valor do veículo mais barato entre os veículos com 
            //potência do motor 1.0, e ainda, valor da prestação do 
            //financiamento em 60 meses.
            VeiculoMB=1000000000000000000;
            //Repetição para análise de veículos com motor 1.0
            for(x=0, y=0; x<qtde;){
                //Veículos com motor 1.0, análise do que tem o menor preço
                //dentre eles e a placa do mesmo
                if(BD[x].potencia_do_motor=="1.0"){
                    y++;
                    Valor=BD[x].valor;
                    if(Valor < VeiculoMB){
                        VeiculoMB=Valor;
                        PlacaVMB=BD[x].placa;
                        ModeloMB=BD[x].modelo;
                    }
                }
                x++;
            }
            //Condição caso não exista nenhum veículo com motor 1.0
            if(y!=0){
                cout<<"\n\nVeículo mais barato com motor 1.0.";
                cout<<"\nModelo: "<<ModeloMB;
                cout<<"\nValor: R$"<<VeiculoMB;
                cout<<"\nPlaca: "<<PlacaVMB;
                cout<<"\nValor da prestação deste veículo com financiamento de "
                        "60 meses: R$"<<PRESTAÇAO;
            }
            else{
                cout<<"\nNão existe nenhum carro com o motor 1.0 no banco de "
                        "dados.";
            }
            
            //------------------------------------------------------------------
            //Placa e valor do veículo mais caro com direção hidráulica e 
            //câmbio automático, e ainda, valor do seguro estimado.
            VeiculoMC=1;
            Valor=0;
            //Repetição para análise dos veículos que possuem direção
            //hidráulica e câmbio automático ao mesmo tempo
            for(x=0, y=0; x<qtde;){
                //Análise do veículo com maior valor e sua placa dentre os que
                //satisfazem a condição de direção e câmbio
                if(BD[x].direçao=="Hidráulica" && BD[x].cambio=="Automático"){
                    y++;
                    Valor=BD[x].valor;
                    if(Valor > VeiculoMC){
                        VeiculoMC=Valor;
                        PlacaVMC=BD[x].placa;
                        ModeloMC=BD[x].modelo;
                    }
                }
                x++;
            }
            //Atribução da taxa de seguro conforme o valor do veículo
            if(VeiculoMC>=20000 && VeiculoMC<=30000){
                SeguroAnual=0.02;
            }
            if(VeiculoMC>30000 && VeiculoMC<=50000){
                SeguroAnual=0.03;
            }
            if(VeiculoMC>50000 && VeiculoMC<=70000){
                SeguroAnual=0.04;
            }
            if(VeiculoMC>70000 && VeiculoMC<=100000){
                SeguroAnual=0.05;
            }
            if(VeiculoMC>100000 && VeiculoMC<=150000){
                SeguroAnual=0.06;
            }
            if(VeiculoMC>150000 && VeiculoMC<=200000){
                SeguroAnual=0.07;
            }
            //Condição para caso não exista nenhum carro que satisfaça as
            //condições de direção e câmbio
            if(y!=0){
                cout<<"\n\nVeículo mais caro com direção hidráulica e "
                       "câmbio automático. ";
                cout<<"\nModelo: "<<ModeloMC;
                cout<<"\nValor: R$"<<VeiculoMC;
                cout<<"\nPlaca: "<<PlacaVMC;
                cout<<"\nEstimativa do valor de seguro anual deste veículo: R$"
                        ""<<SeguroAnual*VeiculoMC;
            }
            else{
                cout<<"\nNão existe nenhum carro com a direção hidráulica"
                        "e o câmbio automático ao mesmo tempo no banco de "
                        "dados.";
            }
            
            //------------------------------------------------------------------
            //Quantidade e média de quilometragem dos veículos com 5 anos 
            //ou mais.
            MediaKM=0;
            QTDEAno=0;
            //Repetição para análise de carros com 5 anos ou mais
            for(x=0, y=0; x<qtde;){
                //Quantidade e quilometragem dos carros com 5 anos ou mais
                if(BD[x].ano<=2019){
                    y++;
                    QTDEAno++;
                    MediaKM=MediaKM+BD[x].quilometragem;
                }
                x++;
            }
            //Condição para caso não exista nenhum carro com 5 anos ou mais
            if(y!=0){
                //Exibição e cálculo da média de quilometragem
                cout<<"\n\nCarros com 5 anos ou mais.";
                cout<<"\nQuantidade: "<<QTDEAno;
                cout<<"\nMédia de quilometragem dos "
                        "mesmos: "<<MediaKM/QTDEAno<<"km";
            }
            else{
                cout<<"\nNão existem veículos com 5 anos ou mais no banco de "
                        "dados.";
            }
            break;
            //FIM do relatório_Caso-6
                
      }
    }while(opçao!=0);
    
    //Comando para atribuir ao arquivo de texto o status de arquivo de escrita
    ofstream arquivoS("ArquivoVeículos.txt");
    //Repetição para reescrita do arquivo de texto
    for(x=0; x<qtde;){
        if(BD[x].valido==true){
            arquivoS<<BD[x].modelo<<" ";
            arquivoS<<BD[x].marca<<" ";  
            arquivoS<<BD[x].tipo<<" "; 
            arquivoS<<BD[x].ano<<" ";
            arquivoS<<BD[x].quilometragem<<" ";
            arquivoS<<BD[x].potencia_do_motor<<" ";
            arquivoS<<BD[x].combustivel<<" ";  
            arquivoS<<BD[x].cambio<<" ";
            arquivoS<<BD[x].direçao<<" ";  
            arquivoS<<BD[x].cor<<" ";    
            arquivoS<<BD[x].portas<<" ";   
            arquivoS<<BD[x].placa<<" ";
            arquivoS<<BD[x].valor<<endl;
        }   
        x++;
    }
    //Escrita do fim no arquivo de texto
    arquivoS<<"FIM";
   
    return 0;
}

