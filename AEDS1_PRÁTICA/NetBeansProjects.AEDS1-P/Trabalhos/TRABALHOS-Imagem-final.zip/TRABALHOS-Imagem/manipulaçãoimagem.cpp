/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include "manipulaçãoimagem.h"



int escurecerclarear(Timagem v, int NLinhas, int NColunas, int fator, int operaçao){
    int x, y;
    for(x=0; x<NLinhas; x++){
        for(y=0; y<NColunas; y++){
            if(v[x][y]>=fator){
            v[x][y]=v[x][y]+(operaçao*fator);
            }
        }
    }
    return 0;
}

int negativar(Timagem v, int NLinhas, int NColunas){
    int x, y;
    
    for(x=0; x<NLinhas; x++){
        for(y=0; y<NColunas; y++){
            v[x][y]=255-v[x][y];
        }
    }
    return 0;
}

int binarizar(Timagem v, int NLinhas, int NColunas, int fator){
    int x, y;
    
    for(x=0; x<NLinhas; x++){
        for(y=0; y<NColunas; y++){
            if(v[x][y]>=fator){
                v[x][y]=255;
            }
            if(v[x][y]<fator){
                v[x][y]=0;
            }
        }
    }
    return 0;
}


int ruidos(Timagem v, int NLinhas, int NColunas, int fator){
    int x, y, Rbranco=0, Rpreto=0, w, z, a, b;
    srand(time(NULL));
    
    Rbranco=fator/2;
    Rpreto=fator/2;
    
    //Ruídos
    for(x=0, w=0, z=0, a=0, b=0; x<NLinhas; x++){
        for(y=0; y<NColunas; y++){
            if(a<Rbranco){
            w=rand()%404;
            z=rand()%600;
            v[w][z]=255;
            a++;
            }
            if(b<Rpreto){
            w=rand()%404;
            z=rand()%600;
            v[w][z]=0;
            b++;
            }
        }
    }
    return 0;
}

int iconizar(Timagem v, int Nlinhas, int Ncolunas, int *linhas, int *colunas){
    int Ncolunas2 = Ncolunas/64, Nlinhas2 = Nlinhas/64, soma = 0;
    int d = Ncolunas2 * Nlinhas2;
    int temp[Nlinhas][Ncolunas];
    *linhas = 64;
    *colunas = 64;
    
    for(int i = 0;i<Nlinhas;i++)
        for(int j = 0;j<Ncolunas;j++)
            temp[i][j] = v[i][j];
    
    for(int i=0;i<Nlinhas;i += Nlinhas2)
        for(int j=0;j<Ncolunas;j += Ncolunas2){
            for(int k = i;k<Nlinhas2+i; k++)
                for(int l = j;l<Ncolunas2+j;l++)
                    soma += temp[k][l];
            v[i/Nlinhas2][j/Ncolunas2] = soma/d;
            soma = 0;
        }
}

void suaviza(Timagem m, int l, int c){
    int soma = 0;
    for(int i = 1; i < l-1; i++)
        for(int j = 1; j< c-1; j++){
            for(int k = -1; k < 2; k++)
                for(int n = -1; n < 2; n++)
                    if(i+k >= 0 && j+n >= 0)
                        if(k != 0 || j != 0)
                            soma += m[i+k][j+n];
            m[i][j] = soma/8;
            soma = 0;
        }
}