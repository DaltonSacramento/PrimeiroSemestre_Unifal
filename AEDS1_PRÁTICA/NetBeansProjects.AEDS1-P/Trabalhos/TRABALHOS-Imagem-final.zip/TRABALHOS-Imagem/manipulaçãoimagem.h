/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   manipulaçãoimagem.h
 * Author: 2024.1.08.005
 *
 * Created on 18 de junho de 2024, 15:53
 */

#ifndef MANIPULAÇÃOIMAGEM_H
#define MANIPULAÇÃOIMAGEM_H

typedef int Timagem[404][600];
int opçao();
int iconizar(Timagem v, int Nlinhas, int Ncolunas, int *linhas, int *colunas);
int escurecerclarear(Timagem v, int NLinhas, int NColunas, int Intens, int operaçao);
int negativar(Timagem v, int NLinhas, int NColunas);
int binarizar(Timagem v, int NLinhas, int NColunas, int fator);
int ruidos(Timagem v, int NLinhas, int NColunas, int fator);
void suaviza(Timagem m, int l, int c);

#endif /* MANIPULAÇÃOIMAGEM_H */

