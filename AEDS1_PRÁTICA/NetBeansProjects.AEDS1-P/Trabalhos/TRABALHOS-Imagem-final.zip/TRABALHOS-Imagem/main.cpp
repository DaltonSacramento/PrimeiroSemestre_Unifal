/*
 *  Aplicação feita para manipulação de imagens em formato de matrizes 
 * implementando funcionalidades que geram novas imagens a partir de imagens 
 * carregadas de arquivos-texto em formato PGM.
 */

/* 
 * File:   main.cpp
 * Author1: Dalton D'angelis Sacramento 2024.1.08.005
 * Author2: Nicolas Rodrigues Teixeira de Oliveira 2023.1.08.047
 * Created on 11 de junho de 2024, 16:19
 */

#include <cstdlib>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <string>
#include <time.h>
#include <fstream>
#include "manipulaçãoimagem.h"

using namespace std;

/*
 * 
 */


int opçao(){
    cout<<"\n";
    int x;
    int resposta;
    cout<<"\n--------------MENU DE ESCOLHA---------------\n";
    cout<<"\n1 - Escurecer ou Clarear";
    cout<<"\n2 - Negativar";
    cout<<"\n3 - Binarizar";
    cout<<"\n4 - Iconizar";
    cout<<"\n5 - Criar ruídos";
    cout<<"\n6 - Colocar filtro";
    cout<<"\n0 - Sair"<<endl<<endl;
    
    cout<<"\nDigite a opção desejada: ";
    cin>>resposta;
    while(resposta != 1 && resposta !=2 && resposta !=3 && resposta !=4 
            && resposta !=5 && resposta !=6 && resposta !=0){
        cout<<"\nValor inválido, digite novamente.";
        cout<<"\nDigite aqui um valor de 0 a 4: ";
        cin>>resposta;
    }
    cout<<endl;
    
    return resposta;
}

int main(int argc, char** argv) {
    
    ifstream arquivoE("stanfordM.txt");
    if(!arquivoE.is_open()){
        cout<<"ERRO: arquivo não existe."<<endl;
        return 1;
    }
    int x, y, w, operaçao, fator;
    int Tamanho, MBranco, NColunas, NLinhas;
    string TipoArq;
    Timagem v;
    
    
    //Ler matriz de entrada
    //Ler parametros da matriz
    arquivoE>>TipoArq;
    arquivoE>>NColunas;
    arquivoE>>NLinhas;
    arquivoE>>MBranco;
    //Ler matriz
    for(x=0; x<NLinhas; x++){
        for(y=0; y<NColunas; y++){
            arquivoE>>v[x][y];
        }
    }
   
    
    
    do{
        switch (w=opçao()){

            //Escurecer ou clarear
            case 1:
                cout<<"\nDigite '1' para clarear ou '-1' para escurecer: ";
                cin>>operaçao;
                cout<<"\nAgora digite um número entre 0 e 255, ou seja, o parâmetro"
                        " para alteração da intensidade das cores: ";
                cin>>fator;
                //Escurecer ou Clarear
                escurecerclarear(v,NLinhas,NColunas,fator,operaçao);
                break;

            //Imagem negativa   
            case 2:
                negativar(v,NLinhas,NColunas);
                break;

            //Binarizar    
            case 3:
                cout<<"\nDigite um valor para binarizar a imagem em função do mesmo: ";
                cin>>fator;
                //Binarizar em função de um fator
                binarizar(v,NLinhas,NColunas,fator);
                break;


            //Iconizar    
            case 4:
                iconizar(v,NLinhas,NColunas,&NLinhas,&NColunas);
                break;

            //Ruídos    
            case 5:
                cout<<"\nDigite o número de ruídos desejados na imagem: ";
                cin>>fator;
                ruidos(v,NLinhas,NColunas,fator);
                break;

            //Filtro   
            case 6:
                suaviza(v,NLinhas,NColunas);
                break;

        }
    }while(w!=0);
    
    
    ofstream arquivoS("stanfordS.pgm");
    //Escrever nova matriz
    //Escrever parâmetros da nova matriz
    arquivoS<<TipoArq<<endl;
    arquivoS<<NColunas<<" ";
    arquivoS<<NLinhas<<endl;
    arquivoS<<MBranco<<endl;
    //Exibir nova matriz
    for(x=0; x<NLinhas; x++){
        for(y=0; y<NColunas; y++){
            arquivoS<<v[x][y];
            arquivoS<<" ";
        }
        arquivoS<<"\n";
    }

    return 0;
}

